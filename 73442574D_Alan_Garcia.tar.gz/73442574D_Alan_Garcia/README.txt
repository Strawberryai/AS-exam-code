Este examen ha sido resuelto en el repositorio https://github.com/Strawberryai/AS-exam-code 
con ayuda del repositorio https://github.com/Strawberryai/AS-CI-CD-ej1
